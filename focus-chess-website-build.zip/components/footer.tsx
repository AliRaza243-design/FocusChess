import Link from 'next/link'

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4 text-foreground">FocusChess</h3>
            <p className="text-sm text-muted-foreground">
              Master the game of chess with our focused, clean platform designed for players of all levels.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Game</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/play" className="hover:text-foreground transition-colors">
                  Play Now
                </Link>
              </li>
              <li>
                <Link href="/learn" className="hover:text-foreground transition-colors">
                  Learn Chess
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/about" className="hover:text-foreground transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-foreground transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/privacy" className="hover:text-foreground transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            &copy; 2024 FocusChess. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-4 md:mt-0">
            FocusChess uses Google AdSense for monetization. Third-party cookies are used to improve your experience.
          </p>
        </div>
      </div>
    </footer>
  )
}
