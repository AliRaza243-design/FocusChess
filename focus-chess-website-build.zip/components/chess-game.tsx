'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

type Piece = 'p' | 'r' | 'n' | 'b' | 'q' | 'k' | 'P' | 'R' | 'N' | 'B' | 'Q' | 'K' | null
type Square = Piece

interface GameState {
  board: Square[][]
  whiteTime: number
  blackTime: number
  currentPlayer: 'white' | 'black'
  selectedSquare: [number, number] | null
  validMoves: [number, number][]
  gameOver: boolean
  winner: 'white' | 'black' | 'draw' | null
}

const INITIAL_BOARD: Square[][] = [
  ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
  ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
  ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
]

const PIECE_SYMBOLS: Record<Piece, string> = {
  'p': '♟',
  'r': '♜',
  'n': '♞',
  'b': '♝',
  'q': '♛',
  'k': '♚',
  'P': '♙',
  'R': '♖',
  'N': '♘',
  'B': '♗',
  'Q': '♕',
  'K': '♔',
  'null': '',
  null: '',
}

export function ChessGame({ initialTime = 600 }: { initialTime?: number }) {
  const [gameState, setGameState] = useState<GameState>({
    board: INITIAL_BOARD.map((row) => [...row]),
    whiteTime: initialTime,
    blackTime: initialTime,
    currentPlayer: 'white',
    selectedSquare: null,
    validMoves: [],
    gameOver: false,
    winner: null,
  })

  const [timerActive, setTimerActive] = useState(true)

  // Timer logic
  useEffect(() => {
    if (!timerActive || gameState.gameOver) return

    const interval = setInterval(() => {
      setGameState((prev) => {
        const newState = { ...prev }
        if (prev.currentPlayer === 'white') {
          newState.whiteTime = Math.max(0, prev.whiteTime - 1)
          if (newState.whiteTime === 0) {
            newState.gameOver = true
            newState.winner = 'black'
          }
        } else {
          newState.blackTime = Math.max(0, prev.blackTime - 1)
          if (newState.blackTime === 0) {
            newState.gameOver = true
            newState.winner = 'white'
          }
        }
        return newState
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [timerActive, gameState.gameOver])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getPieceColor = (piece: Piece) => {
    if (!piece) return null
    return piece === piece.toUpperCase() ? 'white' : 'black'
  }

  const canMoveTo = (fromRow: number, fromCol: number, toRow: number, toCol: number, board: Square[][]) => {
    const piece = board[fromRow][fromCol]
    if (!piece) return false

    const target = board[toRow][toCol]
    const pieceColor = piece === piece.toUpperCase() ? 'white' : 'black'
    
    if (target && getPieceColor(target) === pieceColor) return false

    const type = piece.toLowerCase()

    switch (type) {
      case 'p': {
        const direction = pieceColor === 'white' ? -1 : 1
        const startRow = pieceColor === 'white' ? 6 : 1

        if (fromCol === toCol) {
          if (toRow === fromRow + direction && !target) return true
          if (fromRow === startRow && toRow === fromRow + 2 * direction && !board[fromRow + direction][fromCol] && !target) {
            return true
          }
        } else if (Math.abs(fromCol - toCol) === 1 && toRow === fromRow + direction && target) {
          return true
        }
        return false
      }
      case 'r':
        return (fromRow === toRow || fromCol === toCol) && isPathClear(fromRow, fromCol, toRow, toCol, board)
      case 'n':
        return (
          (Math.abs(fromRow - toRow) === 2 && Math.abs(fromCol - toCol) === 1) ||
          (Math.abs(fromRow - toRow) === 1 && Math.abs(fromCol - toCol) === 2)
        )
      case 'b':
        return Math.abs(fromRow - toRow) === Math.abs(fromCol - toCol) && isPathClear(fromRow, fromCol, toRow, toCol, board)
      case 'q':
        return (
          (fromRow === toRow || fromCol === toCol || Math.abs(fromRow - toRow) === Math.abs(fromCol - toCol)) &&
          isPathClear(fromRow, fromCol, toRow, toCol, board)
        )
      case 'k':
        return Math.abs(fromRow - toRow) <= 1 && Math.abs(fromCol - toCol) <= 1
      default:
        return false
    }
  }

  const isPathClear = (fromRow: number, fromCol: number, toRow: number, toCol: number, board: Square[][]): boolean => {
    const rowDir = fromRow === toRow ? 0 : fromRow < toRow ? 1 : -1
    const colDir = fromCol === toCol ? 0 : fromCol < toCol ? 1 : -1

    let currentRow = fromRow + rowDir
    let currentCol = fromCol + colDir

    while (currentRow !== toRow || currentCol !== toCol) {
      if (board[currentRow][currentCol]) return false
      currentRow += rowDir
      currentCol += colDir
    }

    return true
  }

  const getValidMoves = (row: number, col: number): [number, number][] => {
    const moves: [number, number][] = []
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if ((r !== row || c !== col) && canMoveTo(row, col, r, c, gameState.board)) {
          moves.push([r, c])
        }
      }
    }
    return moves
  }

  const handleSquareClick = (row: number, col: number) => {
    if (gameState.gameOver) return

    const piece = gameState.board[row][col]
    const pieceColor = piece ? getPieceColor(piece) : null

    // If selecting a valid move, execute it
    if (gameState.selectedSquare && gameState.validMoves.some((m) => m[0] === row && m[1] === col)) {
      const newBoard = gameState.board.map((r) => [...r])
      const [fromRow, fromCol] = gameState.selectedSquare
      newBoard[row][col] = newBoard[fromRow][fromCol]
      newBoard[fromRow][fromCol] = null

      setGameState((prev) => ({
        ...prev,
        board: newBoard,
        currentPlayer: prev.currentPlayer === 'white' ? 'black' : 'white',
        selectedSquare: null,
        validMoves: [],
      }))
      return
    }

    // If selecting a piece of the current player
    if (pieceColor === gameState.currentPlayer) {
      const moves = getValidMoves(row, col)
      setGameState((prev) => ({
        ...prev,
        selectedSquare: [row, col],
        validMoves: moves,
      }))
      return
    }

    // Deselect
    setGameState((prev) => ({
      ...prev,
      selectedSquare: null,
      validMoves: [],
    }))
  }

  const resetGame = (time: number) => {
    setGameState({
      board: INITIAL_BOARD.map((row) => [...row]),
      whiteTime: time,
      blackTime: time,
      currentPlayer: 'white',
      selectedSquare: null,
      validMoves: [],
      gameOver: false,
      winner: null,
    })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">Black</p>
            <p className={`text-3xl font-bold ${gameState.currentPlayer === 'black' && !gameState.gameOver ? 'text-foreground' : 'text-muted-foreground'}`}>
              {formatTime(gameState.blackTime)}
            </p>
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">Current Player</p>
            <p className="text-xl font-semibold text-foreground capitalize">
              {gameState.gameOver ? (gameState.winner === 'draw' ? 'Draw' : `${gameState.winner} wins!`) : gameState.currentPlayer}
            </p>
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">White</p>
            <p className={`text-3xl font-bold ${gameState.currentPlayer === 'white' && !gameState.gameOver ? 'text-foreground' : 'text-muted-foreground'}`}>
              {formatTime(gameState.whiteTime)}
            </p>
          </div>
        </Card>
      </div>

      <Card className="p-4">
        <div className="inline-block border-2 border-foreground bg-muted">
          {gameState.board.map((row, rowIndex) => (
            <div key={rowIndex} className="flex">
              {row.map((piece, colIndex) => (
                <button
                  key={`${rowIndex}-${colIndex}`}
                  onClick={() => handleSquareClick(rowIndex, colIndex)}
                  className={`w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center text-2xl sm:text-4xl font-bold border border-border transition-colors
                    ${(rowIndex + colIndex) % 2 === 0 ? 'bg-background' : 'bg-muted'}
                    ${gameState.selectedSquare?.[0] === rowIndex && gameState.selectedSquare?.[1] === colIndex ? 'ring-2 ring-primary' : ''}
                    ${gameState.validMoves.some((m) => m[0] === rowIndex && m[1] === colIndex) ? 'ring-2 ring-accent ring-inset' : ''}
                    hover:opacity-80
                  `}
                >
                  {piece && PIECE_SYMBOLS[piece]}
                </button>
              ))}
            </div>
          ))}
        </div>
      </Card>

      <div className="flex gap-2 flex-wrap">
        <Button onClick={() => resetGame(600)} variant="outline">
          New Game (10 min)
        </Button>
        <Button onClick={() => resetGame(300)} variant="outline">
          New Game (5 min)
        </Button>
        <Button onClick={() => resetGame(900)} variant="outline">
          New Game (15 min)
        </Button>
        <Button onClick={() => setTimerActive(!timerActive)} variant="secondary">
          {timerActive ? 'Pause Timer' : 'Resume Timer'}
        </Button>
      </div>

      <Card className="p-4 bg-muted">
        <p className="text-sm text-muted-foreground">
          <strong>How to play:</strong> Click a piece to select it, then click a highlighted square to move it. The timer switches automatically after each move.
        </p>
      </Card>
    </div>
  )
}
