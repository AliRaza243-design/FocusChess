import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'

export const metadata = {
  title: 'Privacy Policy - FocusChess',
  description: 'FocusChess Privacy Policy covering data collection, usage, cookies, and Google AdSense.',
}

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-2 text-center">Privacy Policy</h1>
          <p className="text-center text-muted-foreground mb-8">Last updated: February 2024</p>

          <Card className="p-8 bg-card border border-border mb-8">
            <p className="text-muted-foreground mb-4">
              FocusChess ("we", "us", "our", or "the Company") operates the FocusChess website and application. This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our service and the choices you have associated with that data.
            </p>
            <p className="text-muted-foreground">
              We use your data to provide and improve our service. By using FocusChess, you agree to the collection and use of information in accordance with this policy.
            </p>
          </Card>

          <div className="space-y-6">
            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">1. Information Collection and Use</h2>
              <p className="text-muted-foreground mb-4">
                FocusChess collects different types of information for various purposes to provide and improve our service to you.
              </p>

              <h3 className="text-lg font-semibold text-foreground mb-3">Types of Data Collected:</h3>
              <ul className="space-y-2 text-muted-foreground text-sm mb-4">
                <li>
                  <strong>Usage Data:</strong> Information about how you use our website, including pages visited, features used, and time spent.
                </li>
                <li>
                  <strong>Device Information:</strong> Device type, operating system, browser type, and IP address.
                </li>
                <li>
                  <strong>Location Data:</strong> Approximate location based on IP address (not precise geolocation).
                </li>
                <li>
                  <strong>Cookie Data:</strong> Information from cookies and similar tracking technologies (see Cookies section below).
                </li>
              </ul>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">2. Cookies and Tracking Technologies</h2>
              <p className="text-muted-foreground mb-4">
                FocusChess uses cookies and similar tracking technologies to enhance user experience and deliver personalized content and advertising through Google AdSense.
              </p>

              <h3 className="text-lg font-semibold text-foreground mb-3">Types of Cookies We Use:</h3>
              <ul className="space-y-3 text-muted-foreground text-sm">
                <li>
                  <strong>Essential Cookies:</strong> Required for the website to function properly.
                </li>
                <li>
                  <strong>Analytics Cookies:</strong> Help us understand how users interact with our website.
                </li>
                <li>
                  <strong>Advertising Cookies:</strong> Used by Google AdSense and other advertising partners to serve relevant advertisements.
                </li>
                <li>
                  <strong>Third-Party Cookies:</strong> Set by external services and partners to provide integrated functionality and advertising.
                </li>
              </ul>
              <p className="text-muted-foreground text-sm mt-4">
                You can control cookie preferences through your browser settings. Disabling cookies may affect the functionality of the site and advertising experience.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">3. Google AdSense and Third-Party Advertising</h2>
              <p className="text-muted-foreground mb-4">
                FocusChess uses Google AdSense to display advertisements on the website. Google and other third-party advertisers use cookies and web beacons to serve ads based on your prior visits to our website and other sites on the internet.
              </p>

              <h3 className="text-lg font-semibold text-foreground mb-3">How Google AdSense Works:</h3>
              <ul className="space-y-2 text-muted-foreground text-sm mb-4">
                <li>• Google may use cookies to display ads based on your interests</li>
                <li>• Your browsing history across websites may be used to personalize ads</li>
                <li>• You can opt out of personalized advertising through Google's ads preferences page</li>
                <li>• We do not have control over Google's data collection practices</li>
              </ul>

              <p className="text-muted-foreground text-sm">
                For more information about Google's privacy practices, please visit <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google's Privacy Policy</a>.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">4. Use of Data</h2>
              <p className="text-muted-foreground mb-3">FocusChess uses the collected data for various purposes:</p>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• To provide and maintain our service</li>
                <li>• To notify you about changes to our service</li>
                <li>• To allow you to participate in interactive features</li>
                <li>• To provide customer care and support</li>
                <li>• To gather analysis and valuable information for service improvement</li>
                <li>• To monitor the usage and trends of the service</li>
                <li>• To deliver targeted advertising through Google AdSense</li>
                <li>• To detect, prevent, and address fraud and security issues</li>
              </ul>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">5. Data Retention</h2>
              <p className="text-muted-foreground">
                FocusChess will retain your Usage Data for analysis purposes. The retention period may vary but typically data will be kept for as long as your account is active and for a reasonable time afterwards for analytical purposes. For more details on cookie retention, please see your browser settings.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">6. Security of Data</h2>
              <p className="text-muted-foreground mb-3">
                The security of your data is important to us. FocusChess implements appropriate technical and organizational measures to protect personal data against unauthorized access, alteration, disclosure, or destruction.
              </p>
              <p className="text-muted-foreground text-sm">
                However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal data, we cannot guarantee its absolute security.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">7. Third-Party Services</h2>
              <p className="text-muted-foreground mb-3">
                FocusChess uses third-party services that may collect information used to identify you:
              </p>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• Google AdSense (advertising)</li>
                <li>• Google Analytics (website analytics)</li>
                <li>• Other advertising partners and analytics providers</li>
              </ul>
              <p className="text-muted-foreground text-sm mt-4">
                We encourage you to review the privacy policies of these third-party services to understand their data handling practices.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">8. Your Privacy Choices</h2>
              <h3 className="text-lg font-semibold text-foreground mb-3">Browser Controls:</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Most browsers allow you to refuse cookies or alert you when a cookie is being sent. You can also delete cookies from your browser settings.
              </p>

              <h3 className="text-lg font-semibold text-foreground mb-3">Google Advertising Preferences:</h3>
              <p className="text-muted-foreground text-sm">
                You can control personalized advertising through Google's <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Ads Preferences Manager</a>.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">9. Changes to This Privacy Policy</h2>
              <p className="text-muted-foreground">
                FocusChess may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date above. You are advised to review this Privacy Policy periodically for any changes.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">10. Contact Us</h2>
              <p className="text-muted-foreground mb-2">
                If you have any questions about this Privacy Policy, please contact us at:
              </p>
              <p className="text-primary">
                <a href="mailto:contact@focuschess.com" className="hover:underline">
                  contact@focuschess.com
                </a>
              </p>
            </Card>
          </div>

          <Card className="p-6 bg-card border border-border mt-8">
            <p className="text-sm text-muted-foreground">
              By using FocusChess, you acknowledge that you have read and understood this Privacy Policy and agree to its terms.
            </p>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
