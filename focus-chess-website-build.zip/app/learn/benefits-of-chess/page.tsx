import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export const metadata = {
  title: 'Benefits of Playing Chess - FocusChess',
  description: 'Discover the cognitive, emotional, and social benefits of playing chess for people of all ages.',
}

export default function BenefitsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/learn" className="text-primary hover:underline mb-6 inline-block">
            ← Back to Learn
          </Link>

          <article className="prose prose-invert max-w-none">
            <h1 className="text-4xl font-bold mb-2">Benefits of Playing Chess</h1>
            <p className="text-muted-foreground mb-8">5 min read</p>

            <Card className="p-6 bg-muted mb-8 border-none">
              <p className="text-foreground">
                Chess is more than just a game. It's a powerful tool for mental development, personal growth, and social connection. Playing chess offers numerous benefits that extend far beyond the board.
              </p>
            </Card>

            <h2 className="text-2xl font-bold mt-8 mb-4">Cognitive Development and Brain Training</h2>
            <p className="text-muted-foreground mb-4">
              Chess is often called "the game that builds your brain." Playing chess requires intense concentration and engages multiple cognitive functions simultaneously. It strengthens pattern recognition, improves visual-spatial reasoning, and enhances working memory. Studies have shown that regular chess players perform better in mathematical and logical problem-solving tasks. The constant need to evaluate positions, calculate variations, and anticipate your opponent's moves creates a comprehensive workout for your brain. Chess players develop the ability to hold complex information in their mind and manipulate it quickly and accurately.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Strategic Thinking and Decision-Making</h2>
            <p className="text-muted-foreground mb-4">
              Chess teaches you to think strategically and make informed decisions. Every move on the chessboard requires consideration of immediate consequences and long-term implications. You learn to evaluate different plans, weigh pros and cons, and choose the best course of action based on incomplete information and time pressure. These decision-making skills transfer directly to real-world situations, from business negotiations to personal planning. Chess players develop the ability to see multiple perspectives, consider alternative approaches, and make calculated decisions even when faced with uncertainty.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Improved Focus and Concentration</h2>
            <p className="text-muted-foreground mb-4">
              In our increasingly distracted world, chess offers a sanctuary of focused attention. Playing chess requires sustained concentration for extended periods. You must block out distractions and maintain mental focus to play at your best. This improvement in concentration extends beyond the chessboard. Many chess players report enhanced focus in their studies and work. The discipline required to play well at chess builds mental habits that improve productivity and achievement in all areas of life. Regular chess play can help combat the scattered attention that characterizes modern life.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Patience and Discipline</h2>
            <p className="text-muted-foreground mb-4">
              Chess teaches patience in a world that often demands instant gratification. Unlike quick entertainment options, chess requires you to slow down and think deeply. You learn that rushing leads to mistakes and that careful consideration yields better results. This develops patience as a personal virtue. Chess also builds discipline through the requirement to study the game, analyze past games, and practice regularly to improve. The progress you make through dedicated effort reinforces the connection between discipline and achievement, a lesson valuable far beyond chess.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Emotional Resilience and Sportsmanship</h2>
            <p className="text-muted-foreground mb-4">
              Chess teaches you to handle both victory and defeat with grace. Losses, even devastating ones, are part of the chess journey. Learning to analyze defeats objectively and extract lessons from them builds emotional resilience. You develop the ability to cope with setbacks and bounce back stronger. Chess also teaches humility—no matter how good you become, there are always stronger players to remind you there is always room for improvement. These experiences in chess foster emotional maturity and the resilience needed to face challenges in life.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Social Connection and Community</h2>
            <p className="text-muted-foreground mb-4">
              Despite being an ancient game, chess creates vibrant communities. Chess clubs, tournaments, and online communities connect players of all ages and backgrounds. Playing chess with others builds relationships and creates a sense of belonging to a larger community. In an increasingly digital world, over-the-board chess provides face-to-face interaction and social engagement. Chess friendships often transcend the game, and the shared passion for chess creates bonds between people who might otherwise never meet. Whether playing casually with friends or competing in tournaments, chess provides valuable social interaction.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Lifelong Learning and Personal Growth</h2>
            <p className="text-muted-foreground mb-4">
              Chess is a game of infinite depth. No matter how skilled you become, there is always more to learn. This creates a framework for continuous improvement and lifelong learning. Working to improve at chess builds self-confidence and a growth mindset. Players learn that improvement comes through effort, study, and practice. This mindset extends beyond chess and influences how people approach challenges and learning opportunities throughout their lives. Chess players often become more intellectually curious and engaged learners.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Fun and Enjoyment</h2>
            <p className="text-muted-foreground mb-4">
              Above all, chess is fun. The satisfaction of executing a brilliant strategy, the tension of a close game, and the joy of checkmate—these experiences are intrinsically rewarding. Chess offers entertainment that is both intellectually engaging and emotionally satisfying. Whether you play for competition or leisure, chess provides enjoyment that doesn't depend on external rewards.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Conclusion</h2>
            <p className="text-muted-foreground mb-4">
              The benefits of playing chess extend far beyond the 64 squares. Chess develops your mind, builds character, and creates connections with others. Whether you're looking to improve your cognitive abilities, develop better decision-making skills, or simply find an engaging hobby, chess offers something valuable. Start playing today and begin reaping the remarkable benefits that chess has to offer.
            </p>

            <Card className="p-6 bg-muted border-none mt-8">
              <p className="text-foreground mb-4">
                Ready to experience the benefits of chess? Join the FocusChess community today and start your chess journey!
              </p>
              <Link href="/play" className="text-primary hover:underline font-semibold">
                Start Playing →
              </Link>
            </Card>
          </article>
        </div>
      </main>

      <Footer />
    </div>
  )
}
