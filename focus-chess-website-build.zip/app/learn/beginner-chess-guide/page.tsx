import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export const metadata = {
  title: 'How to Play Chess: A Beginner\'s Guide - FocusChess',
  description: 'Learn chess from scratch with our complete beginner\'s guide covering piece movements, basic strategies, and game fundamentals.',
}

export default function BeginnerGuidePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/learn" className="text-primary hover:underline mb-6 inline-block">
            ← Back to Learn
          </Link>

          <article className="prose prose-invert max-w-none">
            <h1 className="text-4xl font-bold mb-2">How to Play Chess: A Beginner's Guide</h1>
            <p className="text-muted-foreground mb-8">5 min read</p>

            <Card className="p-6 bg-muted mb-8 border-none">
              <p className="text-foreground">
                Chess is a timeless game of strategy that combines simple rules with infinite complexity. This guide will teach you everything you need to know to start playing chess today.
              </p>
            </Card>

            <h2 className="text-2xl font-bold mt-8 mb-4">Understanding the Board</h2>
            <p className="text-muted-foreground mb-4">
              Chess is played on an 8x8 board with alternating light and dark squares. The board is always set up with a light square in the bottom-right corner. Each player begins with 16 pieces: one king, one queen, two rooks, two bishops, two knights, and eight pawns. The vertical columns are called files, and the horizontal rows are called ranks.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">The Chess Pieces and How They Move</h2>
            <p className="text-muted-foreground mb-4">
              Each chess piece moves in a unique way. Understanding these movements is fundamental to playing the game:
            </p>

            <div className="space-y-4 mb-6">
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♙ The Pawn</h3>
                <p className="text-muted-foreground text-sm">
                  Pawns move forward one square, or two squares on their first move. They capture diagonally forward. Pawns are the most numerous pieces but also the least powerful. When a pawn reaches the opposite end of the board, it promotes to a queen, rook, bishop, or knight of your choice.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♖ The Rook</h3>
                <p className="text-muted-foreground text-sm">
                  Rooks move horizontally or vertically any number of squares. They are powerful pieces worth about five points. Rooks become increasingly powerful in the endgame when there are fewer pieces on the board.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♘ The Knight</h3>
                <p className="text-muted-foreground text-sm">
                  Knights move in an L-shape: two squares in one direction and one square perpendicular, or vice versa. Knights are the only pieces that can jump over other pieces. They are worth about three points and are excellent for creating tactical opportunities.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♗ The Bishop</h3>
                <p className="text-muted-foreground text-sm">
                  Bishops move diagonally any number of squares. Each bishop stays on its original color throughout the game. Two bishops working together are slightly more powerful than two knights. A bishop is worth about three points.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♕ The Queen</h3>
                <p className="text-muted-foreground text-sm">
                  The queen is the most powerful piece. It combines the moves of the rook and bishop, moving any number of squares horizontally, vertically, or diagonally. The queen is worth about nine points and is invaluable in attack and defense.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">♔ The King</h3>
                <p className="text-muted-foreground text-sm">
                  The king moves one square in any direction. While the king is the most important piece—losing it means losing the game—it is also the most vulnerable during the opening and middlegame. Protecting your king is always a priority.
                </p>
              </div>
            </div>

            <h2 className="text-2xl font-bold mt-8 mb-4">Basic Rules and Concepts</h2>
            <p className="text-muted-foreground mb-4">
              <strong>Check:</strong> Your king is in check when it is under direct attack. When in check, you must make a move that removes your king from danger.
            </p>
            <p className="text-muted-foreground mb-4">
              <strong>Checkmate:</strong> This is when your king is in check and there is no legal move to escape. Checkmate ends the game, and the player delivering checkmate wins.
            </p>
            <p className="text-muted-foreground mb-4">
              <strong>Stalemate:</strong> If you are not in check but have no legal moves available, the game is a draw.
            </p>
            <p className="text-muted-foreground mb-4">
              <strong>Piece Values:</strong> Understanding the relative worth of pieces helps with strategic decision-making. Pawns are worth 1 point, knights and bishops are worth 3, rooks are worth 5, and the queen is worth 9. The king is priceless.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Basic Strategy for Beginners</h2>
            <p className="text-muted-foreground mb-4">
              As you begin playing chess, focus on these fundamental principles: develop your pieces quickly, control the center of the board with your pawns and pieces, keep your king safe by castling early, and always look for tactical opportunities to win material. Avoid moving the same piece multiple times in the opening, and try to complete your development before attacking your opponent.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Getting Started</h2>
            <p className="text-muted-foreground mb-4">
              Now that you understand the basics, it's time to start playing! Practice regularly, analyze your games to learn from mistakes, and gradually increase the difficulty of your opponents. Chess is a journey of continuous learning and improvement. Every game teaches you something new, whether you win or lose. The most important thing is to have fun and enjoy this timeless game.
            </p>

            <Card className="p-6 bg-muted border-none mt-8">
              <p className="text-foreground mb-4">
                Ready to test your knowledge? Visit our Play Chess page to challenge a friend to a game with customizable time controls!
              </p>
              <Link href="/play" className="text-primary hover:underline font-semibold">
                Start Playing →
              </Link>
            </Card>
          </article>
        </div>
      </main>

      <Footer />
    </div>
  )
}
