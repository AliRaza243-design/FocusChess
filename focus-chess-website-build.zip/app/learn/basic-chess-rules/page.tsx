import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export const metadata = {
  title: 'Basic Chess Rules Explained - FocusChess',
  description: 'Comprehensive explanation of chess rules including piece movements, special moves, check, checkmate, and more.',
}

export default function BasicRulesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/learn" className="text-primary hover:underline mb-6 inline-block">
            ← Back to Learn
          </Link>

          <article className="prose prose-invert max-w-none">
            <h1 className="text-4xl font-bold mb-2">Basic Chess Rules Explained</h1>
            <p className="text-muted-foreground mb-8">6 min read</p>

            <Card className="p-6 bg-muted mb-8 border-none">
              <p className="text-foreground">
                Chess has a set of rules that govern how the game is played. These rules ensure fair play and create the strategic depth that makes chess so fascinating. Here's a comprehensive guide to the fundamental rules.
              </p>
            </Card>

            <h2 className="text-2xl font-bold mt-8 mb-4">Setting Up the Game</h2>
            <p className="text-muted-foreground mb-4">
              A chess game begins with the board positioned so that there is a light square in the bottom-right corner. Each player has 16 pieces arranged in two rows. The back row contains the king, queen, two rooks, two bishops, and two knights. The front row is filled with eight pawns. White always moves first. The queen begins on a square of its own color: the white queen starts on a light square, and the black queen starts on a dark square.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">How Pieces Move</h2>
            <p className="text-muted-foreground mb-4">
              Each piece has specific movement rules that determine how it can travel across the board. Pieces cannot move through other pieces, except for the knight, which can jump over any piece. When a piece moves to a square occupied by an opponent's piece, it captures that piece, removing it from the board. Your own pieces cannot be captured; you cannot move into a square occupied by your own piece.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Special Moves</h2>

            <div className="space-y-4 mb-6">
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">Castling</h3>
                <p className="text-muted-foreground text-sm">
                  Castling is a special move involving the king and one rook. If neither piece has moved before, they are on their starting squares, and there are no pieces between them, the king can move two squares toward the rook and the rook moves to the square the king crossed. Castling is not allowed if the king is in check, moving through check, or moving into check. This move helps you develop pieces and safeguard your king.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">En Passant</h3>
                <p className="text-muted-foreground text-sm">
                  This special pawn capture occurs when an opponent's pawn moves two squares forward from its starting position and lands beside your pawn. On your next move, you may capture that pawn as if it had moved only one square, moving your pawn diagonally to the empty square behind it. This capture must be made immediately or the opportunity is lost.
                </p>
              </div>

              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold text-foreground mb-2">Pawn Promotion</h3>
                <p className="text-muted-foreground text-sm">
                  When a pawn reaches the opposite end of the board, it is promoted to a new piece of the player's choice: a queen, rook, bishop, or knight. The promoted piece is placed on the promotion square, immediately replacing the pawn. Most players choose a queen because it is the most powerful piece.
                </p>
              </div>
            </div>

            <h2 className="text-2xl font-bold mt-8 mb-4">Check and Checkmate</h2>
            <p className="text-muted-foreground mb-4">
              <strong>Check</strong> occurs when the king is under direct attack by an opponent's piece. When you are in check, you must make a move that removes your king from danger. There are three ways to get out of check: move the king to a safe square, block the attack with another piece, or capture the attacking piece.
            </p>
            <p className="text-muted-foreground mb-4">
              <strong>Checkmate</strong> happens when the king is in check and there is no legal move to escape the attack. This ends the game immediately, and the player who delivered checkmate wins. Checkmate is the ultimate goal of chess.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Stalemate and Draws</h2>
            <p className="text-muted-foreground mb-4">
              <strong>Stalemate</strong> occurs when you have no legal moves available but your king is not in check. The game immediately ends in a draw. A draw also results from mutual agreement, repetition of position three times, fifty moves without a pawn move or capture, or insufficient material to continue the game.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Piece Values and Notation</h2>
            <p className="text-muted-foreground mb-4">
              Understanding relative piece values helps you make good trading decisions: pawns are worth 1 point, knights and bishops are worth approximately 3 points, rooks are worth 5 points, and queens are worth about 9 points. Chess positions are recorded using algebraic notation, where files are labeled a-h and ranks are labeled 1-8. Each piece has a letter (K for king, Q for queen, R for rook, B for bishop, N for knight), and pawns are not given a letter.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Touch-Move and Other Etiquette</h2>
            <p className="text-muted-foreground mb-4">
              In formal chess, the "touch-move" rule states that if you touch a piece, you must move it if doing so is legal. Similarly, if you touch an opponent's piece, you must capture it if possible. In casual play with friends, these rules are often relaxed, but it's good practice to follow them. Chess etiquette also includes maintaining a quiet environment, being respectful to opponents, and resigning when your position is hopeless rather than playing to checkmate.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">Time Controls</h2>
            <p className="text-muted-foreground mb-4">
              In casual play, time controls determine how long each player has to think about their moves. Common time controls include blitz (5 minutes or less), rapid (10-25 minutes), and classical (longer, or unlimited with increment). At FocusChess, you can choose from 5, 10, or 15-minute games where each player has their own countdown timer.
            </p>

            <Card className="p-6 bg-muted border-none mt-8">
              <p className="text-foreground mb-4">
                Now that you understand the rules, put your knowledge into practice! Try a game on FocusChess and experience the thrill of strategic chess.
              </p>
              <Link href="/play" className="text-primary hover:underline font-semibold">
                Play Now →
              </Link>
            </Card>
          </article>
        </div>
      </main>

      <Footer />
    </div>
  )
}
