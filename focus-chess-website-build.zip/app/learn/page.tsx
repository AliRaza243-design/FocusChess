import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export const metadata = {
  title: 'Learn Chess - FocusChess',
  description: 'Learn chess strategies, rules, and improve your game with our comprehensive guides and articles.',
}

export default function LearnPage() {
  const articles = [
    {
      id: 'beginner-rules',
      title: 'How to Play Chess: A Beginner\'s Guide',
      excerpt: 'Learn the fundamentals of chess, from piece movements to basic strategies that will help you start your chess journey.',
      readTime: '5 min',
      slug: 'beginner-chess-guide',
    },
    {
      id: 'basic-rules',
      title: 'Basic Chess Rules Explained',
      excerpt: 'Master the essential rules of chess including piece values, special moves, check, checkmate, and stalemate concepts.',
      readTime: '6 min',
      slug: 'basic-chess-rules',
    },
    {
      id: 'benefits',
      title: 'Benefits of Playing Chess',
      excerpt: 'Discover how chess improves cognitive skills, strategic thinking, patience, and decision-making abilities.',
      readTime: '5 min',
      slug: 'benefits-of-chess',
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 text-center">Learn Chess</h1>
          <p className="text-lg text-muted-foreground text-center mb-12">
            Improve your chess skills with our comprehensive guides and articles.
          </p>

          <div className="grid gap-6 mb-12">
            {articles.map((article) => (
              <Link key={article.id} href={`/learn/${article.slug}`}>
                <Card className="p-6 hover:bg-muted transition-colors cursor-pointer">
                  <h2 className="text-2xl font-semibold mb-2 text-foreground hover:text-primary">
                    {article.title}
                  </h2>
                  <p className="text-muted-foreground mb-4">{article.excerpt}</p>
                  <p className="text-sm text-muted-foreground">{article.readTime} read</p>
                </Card>
              </Link>
            ))}
          </div>

          <Card className="p-6 bg-muted border-2 border-primary">
            <h2 className="text-2xl font-semibold mb-4">Getting Started with Chess</h2>
            <p className="text-muted-foreground mb-4">
              Chess is an ancient game of strategy that has captivated millions of players worldwide. Whether you're a complete beginner or looking to improve your skills, our comprehensive guides will help you on your journey.
            </p>
            <p className="text-muted-foreground">
              Start with our beginner's guide to understand the basics, then explore advanced strategies as you progress. Remember, chess is a game of endless learning and enjoyment—take your time, practice regularly, and most importantly, have fun!
            </p>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
