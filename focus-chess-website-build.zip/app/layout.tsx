import React from "react"
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'

import './globals.css'

const _geist = Geist({ subsets: ['latin'] })
const _geistMono = Geist_Mono({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'FocusChess - Master Strategic Chess Online',
  description: 'Play chess, learn strategies, and improve your game. FocusChess offers a clean, focused platform for casual and competitive chess players.',
  keywords: ['chess', 'online chess', 'chess game', 'learn chess', 'chess strategy'],
  authors: [{ name: 'FocusChess Team' }],
  viewport: 'width=device-width, initial-scale=1',
  robots: 'index, follow',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#1a1a2e',
  userScalable: true,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        {/* AdSense Meta Tags */}
        <meta name="google-site-verification" content="FocusChess" />
        {/* Additional SEO Meta Tags */}
        <meta name="format-detection" content="telephone=no" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
