import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export const metadata = {
  title: 'About FocusChess - Learn Our Story',
  description: 'Learn about FocusChess, our mission to provide a clean, focused chess platform for players of all levels.',
}

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-8 text-center">About FocusChess</h1>

          <Card className="p-8 mb-8 bg-card border border-border">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-muted-foreground mb-4">
              FocusChess is dedicated to providing a clean, distraction-free platform where chess enthusiasts of all skill levels can play, learn, and improve. We believe that chess is more than just a game—it's a powerful tool for developing strategic thinking, improving focus, and building meaningful connections with other players.
            </p>
            <p className="text-muted-foreground">
              Our mission is to make chess accessible and enjoyable for everyone, from curious beginners to experienced players. We focus on creating an intuitive, beautiful interface that lets players concentrate on what matters: the game itself.
            </p>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 bg-muted border border-border">
              <h3 className="text-xl font-semibold mb-3">♟ Pure Chess</h3>
              <p className="text-muted-foreground text-sm">
                No distractions, no unnecessary features—just chess. Our clean interface keeps you focused on the game.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h3 className="text-xl font-semibold mb-3">⏱️ Flexible Time Controls</h3>
              <p className="text-muted-foreground text-sm">
                Play at your own pace with customizable time controls. Choose between blitz, rapid, or classical formats.
              </p>
            </Card>

            <Card className="p-6 bg-muted border border-border">
              <h3 className="text-xl font-semibold mb-3">📚 Learn & Grow</h3>
              <p className="text-muted-foreground text-sm">
                Access comprehensive guides and articles to improve your chess skills at every level.
              </p>
            </Card>
          </div>

          <Card className="p-8 mb-8 bg-card border border-border">
            <h2 className="text-2xl font-bold mb-4">Why Choose FocusChess?</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Community-Focused</h3>
                <p className="text-muted-foreground text-sm">
                  We believe chess is best enjoyed with others. Our platform facilitates friendly competition and knowledge sharing among players of all levels.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Commitment to Accessibility</h3>
                <p className="text-muted-foreground text-sm">
                  Chess should be available to everyone. We've designed FocusChess to be intuitive for beginners while providing depth for experienced players.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Educational Resources</h3>
                <p className="text-muted-foreground text-sm">
                  Beyond the game, we provide articles and guides to help you understand chess strategy, learn the rules, and improve your gameplay.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Fair and Transparent</h3>
                <p className="text-muted-foreground text-sm">
                  We operate with complete transparency about our features, policies, and how we use your data. Your trust is important to us.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-muted border border-border">
            <h2 className="text-2xl font-bold mb-4">Chess for Everyone</h2>
            <p className="text-muted-foreground mb-4">
              Whether you're a complete beginner discovering chess for the first time, a casual player who enjoys games with friends, or an ambitious player working to improve your rating, FocusChess welcomes you. We're committed to supporting your chess journey at every stage.
            </p>
            <p className="text-muted-foreground mb-6">
              Chess has been bringing people together for centuries. From ancient kingdoms to modern times, chess has challenged minds, inspired strategic thinking, and created lasting connections. We're honored to continue this tradition and provide a space where you can experience the timeless appeal of chess.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/play" className="flex-1">
                <button className="w-full bg-primary text-primary-foreground px-6 py-2 rounded-md font-semibold hover:opacity-90 transition-opacity">
                  Play Now
                </button>
              </Link>
              <Link href="/learn" className="flex-1">
                <button className="w-full bg-secondary text-secondary-foreground px-6 py-2 rounded-md font-semibold hover:opacity-90 transition-opacity">
                  Learn Chess
                </button>
              </Link>
            </div>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
