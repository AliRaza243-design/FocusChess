import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-card to-background py-12 sm:py-20 lg:py-28">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-4 sm:space-y-6">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-balance">
                Master the Game of Chess
              </h1>
              <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
                FocusChess provides a clean, distraction-free platform to play chess, learn strategies, and improve your skills. Play with a friend or explore chess fundamentals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Link href="/play">
                  <Button size="lg" className="w-full sm:w-auto">
                    Start Playing
                  </Button>
                </Link>
                <Link href="/learn">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                    Learn Chess
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 sm:py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center">Why Choose FocusChess?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-4">♟</div>
                <h3 className="text-xl font-semibold mb-2">Two-Player Chess</h3>
                <p className="text-muted-foreground">
                  Play against a friend on the same device with proper chess rules and smooth gameplay.
                </p>
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-4">⏱️</div>
                <h3 className="text-xl font-semibold mb-2">Time Controls</h3>
                <p className="text-muted-foreground">
                  Choose from 5, 10, or 15-minute games. Each player has an individual countdown timer.
                </p>
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-4">📚</div>
                <h3 className="text-xl font-semibold mb-2">Learn & Improve</h3>
                <p className="text-muted-foreground">
                  Access chess articles and strategies to enhance your understanding of the game.
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-muted py-12 sm:py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-6">
              <h2 className="text-3xl sm:text-4xl font-bold">Ready to Play?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Jump into a game now and experience focused, clean chess gameplay.
              </p>
              <Link href="/play">
                <Button size="lg">Play Now</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
