import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ChessGame } from '@/components/chess-game'

export const metadata = {
  title: 'Play Chess - FocusChess',
  description: 'Play a two-player chess game with time controls. Choose your time limit and challenge your opponent.',
}

export default function PlayPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-8 text-center">Play Chess</h1>

          <div className="bg-card border border-border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Two-Player Chess Game</h2>
            <p className="text-muted-foreground mb-4">
              Play a classic game of chess with a friend on the same device. Select your preferred time control and start playing immediately.
            </p>
            <ChessGame initialTime={600} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-muted border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-3">Game Rules</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Pieces move according to standard chess rules</li>
                <li>• White always moves first</li>
                <li>• Timers count down for the player whose turn it is</li>
                <li>• A player who runs out of time loses the game</li>
                <li>• Click a piece to select it, then click a highlighted square to move</li>
              </ul>
            </div>

            <div className="bg-muted border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-3">Time Controls</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• <strong>5 Minutes:</strong> Fast-paced blitz chess</li>
                <li>• <strong>10 Minutes:</strong> Balanced game pace</li>
                <li>• <strong>15 Minutes:</strong> Relaxed, strategic play</li>
                <li>• Each player gets their own individual timer</li>
                <li>• Timer switches after every move</li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
