import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'

export const metadata = {
  title: 'Contact FocusChess - Get In Touch',
  description: 'Have questions or feedback? Contact the FocusChess team at contact@focuschess.com',
}

export default function ContactPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-8 text-center">Contact Us</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <Card className="p-8 bg-card border border-border">
              <h2 className="text-2xl font-bold mb-4">Get In Touch</h2>
              <p className="text-muted-foreground mb-6">
                Have questions, feedback, or suggestions? We'd love to hear from you! The FocusChess team is committed to providing excellent support and continuously improving our platform based on user feedback.
              </p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Email</h3>
                  <p className="text-muted-foreground">
                    <a
                      href="mailto:contact@focuschess.com"
                      className="text-primary hover:underline"
                    >
                      contact@focuschess.com
                    </a>
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Response Time</h3>
                  <p className="text-muted-foreground">
                    We strive to respond to all inquiries within 24-48 hours. Thank you for your patience.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 bg-muted border border-border">
              <h2 className="text-2xl font-bold mb-4">How Can We Help?</h2>
              <p className="text-muted-foreground mb-6">
                Whether you have questions about gameplay, need technical support, want to report a bug, or have feature requests, we're here to help. Your input helps us build a better chess platform for everyone.
              </p>

              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>✓ Technical support and bug reports</li>
                <li>✓ Feature requests and suggestions</li>
                <li>✓ Account assistance</li>
                <li>✓ General inquiries and feedback</li>
                <li>✓ Partnership opportunities</li>
              </ul>
            </Card>
          </div>

          <Card className="p-8 bg-card border border-border mb-8">
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>

            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Is FocusChess free to use?</h3>
                <p className="text-muted-foreground text-sm">
                  Yes! FocusChess is completely free to use. We support the platform through non-intrusive advertising via Google AdSense.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Do I need to create an account to play?</h3>
                <p className="text-muted-foreground text-sm">
                  No account creation is required. You can start playing immediately by opening a game on the Play page.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Can I play with computer opponents?</h3>
                <p className="text-muted-foreground text-sm">
                  Currently, FocusChess is designed for two-player games on the same device. We encourage you to challenge a friend to experience the full enjoyment of chess!
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">What time controls are available?</h3>
                <p className="text-muted-foreground text-sm">
                  You can choose from 5, 10, or 15-minute games. Each player receives their own countdown timer that switches after every move.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">How are my privacy and data handled?</h3>
                <p className="text-muted-foreground text-sm">
                  Please review our Privacy Policy for complete information about how we collect, use, and protect your data. Your privacy is important to us.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Can I report a bug or suggest a feature?</h3>
                <p className="text-muted-foreground text-sm">
                  Absolutely! We welcome bug reports and feature suggestions. Please email us at contact@focuschess.com with details about any issues or ideas you have.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-muted border-2 border-primary">
            <h2 className="text-2xl font-bold mb-4">Thank You!</h2>
            <p className="text-muted-foreground mb-4">
              Thank you for your interest in FocusChess. We're passionate about chess and committed to creating the best possible experience for our players. Whether you're just starting your chess journey or you're an experienced player, we're excited to have you as part of the FocusChess community.
            </p>
            <p className="text-muted-foreground">
              Feel free to reach out anytime at <a href="mailto:contact@focuschess.com" className="text-primary hover:underline">contact@focuschess.com</a>. We look forward to hearing from you!
            </p>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
